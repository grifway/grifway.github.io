<?php
  foreach ($_GET as $name => $value) {
    echo $name . '=' . $value . '<br/>';
  }
?>